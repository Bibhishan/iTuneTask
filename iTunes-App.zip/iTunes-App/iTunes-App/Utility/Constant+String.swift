//
//  Constant+String.swift
//  iTunes-App
//
//  Created by Abcom on 10/12/24.
//

import Foundation

enum UIViewControllerString: String {
    case mediaList = "MediaListVC"
    case itemList = "ItemListVC"
    case descriptionVC = "DescriptionVC"
}

enum APIString: String {
    case iTuneAPI = "https://itunes.apple.com/search?term="
}

enum CellIdentifier: String {
    case itemGridCell = "ItemGridCell"
    case itemListCell = "ItemListCell"
    case mediaListCell = "MediaListCell"
}
