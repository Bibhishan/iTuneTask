//
//  MediaListVC.swift
//  iTunes-App
//
//  Created by Abcom on 07/12/24.
//

import UIKit

class MediaListVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var itunesSong: String = ""
    let items = ["Album", "Movieartist", "EBook", "Movie", "Musicvideo", "Podcast", "Song"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Media"
    }

}

extension MediaListVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier.mediaListCell.rawValue, for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: UIViewControllerString.itemList.rawValue) as? ItemListVC {
            vc.itunesSong = itunesSong
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
