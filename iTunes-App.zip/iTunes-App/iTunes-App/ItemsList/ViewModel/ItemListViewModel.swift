//
//  ItemListViewModel.swift
//  iTunes-App
//
//  Created by Abcom on 10/12/24.
//

import Foundation

let session = URLSession(configuration: .default, delegate: CustomSessionDelegate(), delegateQueue: nil)

class ItemListViewModel {
    // Published property to store users
    @Published var ituneListModel: [ItuneListResult] = []
    
    // API Call using async/await
    func fetchUsers(searchText: String) async {
        let urlString = APIString.iTuneAPI.rawValue + searchText
        guard let url = URL(string: urlString) else { return }
        
        do {
            
            let (data, _) = try await session.data(from: url)
            let ituneListModel = try JSONDecoder().decode(ItuneListModel.self, from: data)
                        
            DispatchQueue.main.async {
                self.ituneListModel = ituneListModel.results
            }
        } catch {
            print("Failed to fetch users: \(error)")
        }
    }
}

class CustomSessionDelegate: NSObject, URLSessionDelegate {
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if let serverTrust = challenge.protectionSpace.serverTrust {
            let credential = URLCredential(trust: serverTrust)
            completionHandler(.useCredential, credential)
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}
