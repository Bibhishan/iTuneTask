//
//  ItemListVC.swift
//  iTunes-App
//
//  Created by Abcom on 07/12/24.
//

import UIKit
import Combine

class ItemListVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var itunesSong: String = ""
    private var itemListViewModel = ItemListViewModel()
    private var cancellables: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bindViewModel()
        setupCollectionView()
        Task {
            await itemListViewModel.fetchUsers(searchText: itunesSong)
        }
    }
    
    private func setupCollectionView() {
        // Register header view
        collectionView.register(UINib.init(nibName: CellIdentifier.itemGridCell.rawValue, bundle: nil), forCellWithReuseIdentifier: CellIdentifier.itemGridCell.rawValue)
        collectionView.register(UINib.init(nibName: CellIdentifier.itemListCell.rawValue, bundle: nil), forCellWithReuseIdentifier: CellIdentifier.itemListCell.rawValue)
    }
    
    private func bindViewModel() {
        itemListViewModel.$ituneListModel
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.collectionView.reloadData()
            }
            .store(in: &cancellables)
    }
    
    @IBAction func segmentAction(_ sender: UISegmentedControl) {
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    
    // MARK: - UICollectionViewDataSource Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemListViewModel.ituneListModel.count// Number of items in section
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.itemGridCell.rawValue, for: indexPath) as? ItemGridCell {
                cell.configure(with: itemListViewModel.ituneListModel[indexPath.row])
                return cell
            }
        default:
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CellIdentifier.itemListCell.rawValue, for: indexPath) as? ItemListCell {
                cell.configure(with: itemListViewModel.ituneListModel[indexPath.row])
                return cell
            }
        }
        
        return UICollectionViewCell()
    }
    
    // MARK: - UICollectionViewDelegateFlowLayout Methods
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            return CGSize(width: self.view.frame.size.width / 2 - 10, height: 200) // Adjust cell size
        default:
            return CGSize(width: self.view.frame.size.width - 8, height: 150) // Adjust cell size
        }
        
    }
    
    // Optional: Inset for sections
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10) // Insets for section
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: UIViewControllerString.descriptionVC.rawValue) as? DescriptionVC {
            vc.ituneModel = itemListViewModel.ituneListModel[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

