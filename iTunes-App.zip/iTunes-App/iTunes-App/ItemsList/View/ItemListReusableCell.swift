//
//  ItemListReusableCell.swift
//  iTunes-App
//
//  Created by Abcom on 09/12/24.
//

import UIKit

class ItemListReusableCell: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
