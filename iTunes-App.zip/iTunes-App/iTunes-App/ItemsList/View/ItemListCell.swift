//
//  ItemListCell.swift
//  iTunes-App
//
//  Created by Abcom on 09/12/24.
//

import UIKit
import Kingfisher

class ItemListCell: UICollectionViewCell {

    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var itemTitleLabel: UILabel!
    @IBOutlet weak var artistNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(with item: ItuneListResult) {
        let downloader = KingfisherManager.shared.downloader
        downloader.trustedHosts = Set(["is1-ssl.mzstatic.com"])
        itemImageView.kf.setImage(with: URL(string: item.artworkUrl60 ?? ""))
        itemTitleLabel.text = item.trackName ?? "None"
        artistNameLabel.text = item.artistName ?? "None"
    }

}
