//
//  DescriptionVC.swift
//  iTunes-App
//
//  Created by Abcom on 07/12/24.
//

import UIKit
import Kingfisher
import WebKit

class DescriptionVC: UIViewController {

    @IBOutlet weak var trackImage: UIImageView!
    @IBOutlet weak var trackName: UILabel!
    @IBOutlet weak var artistName: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    @IBOutlet weak var webView: WKWebView!
    
    var ituneModel: ItuneListResult?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadVideoInWebView()
    }
    
    func loadVideoInWebView() {
        // Example YouTube embed link
        let videoHTML = """
            <html>
            <body style='margin: 0; padding: 0;'>
                <iframe width="\(self.webView.frame.size.width)" height="200" src="\(ituneModel?.previewURL ?? "")" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </body>
            </html>
            """
        webView.loadHTMLString(videoHTML, baseURL: nil)
    }
    
    private func setupUI() {
        let downloader = KingfisherManager.shared.downloader
        downloader.trustedHosts = Set(["is1-ssl.mzstatic.com"])
        trackImage.kf.setImage(with: URL(string: ituneModel?.artworkUrl60 ?? ""))
        trackName.text = ituneModel?.trackName
        artistName.text = ituneModel?.artistName
        descriptionLbl.text = ituneModel?.longDescription ?? "None"
    }
}
