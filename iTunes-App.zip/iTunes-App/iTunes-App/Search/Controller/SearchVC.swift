//
//  ViewController.swift
//  iTunes-App
//
//  Created by Abcom on 07/12/24.
//

import UIKit

class SearchVC: UIViewController {

    @IBOutlet weak var ituneSearchTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func searchBtnTapped(_ sender: UIButton) {
        if let searchText = ituneSearchTF.text, !searchText.isEmpty {
            if let vc = self.storyboard?.instantiateViewController(withIdentifier: UIViewControllerString.mediaList.rawValue) as? MediaListVC{
                vc.itunesSong = searchText
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}

